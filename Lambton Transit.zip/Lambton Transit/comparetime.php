
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <link rel="stylesheet" href="../css/spectre.min.css">
    <link rel="stylesheet" href="../css/spectre-exp.min.css">
    <link rel="stylesheet" href="./css/spectre-icons.min.css">
  </head>
  <body>
    <header>
      <h1> ADMIN AREA </h1>
	<select name="pick_up" id="pick_up">

  <option value="">Select...</option>

  <option value="Brampton">Brampton</option>

  <option value="Mississuaga">Mississuaga</option>
  <option value="Lambton college">Lambton college</option>

</select>

	  
	<select name="drop_location" id="drop_location">

  <option value="">Select...</option>

 
  <option value="Brampton">Brampton</option>

  <option value="Mississuaga">Mississuaga</option>
  <option value="Lambton college">Lambton college</option>

</select>  
	  
<button type="button"> Next Buses</button>	  
	  
	  
	  
    </header>

    <?php

      $dbhost = "localhost";
      $dbuser = "root";
      $dbpass = "";
      $dbname = "lambtontransit";

      $connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

      if (mysqli_connect_errno())
      {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
        exit();
      }
	  
	  // set the current time zone
date_default_timezone_set("America/New_York");

// get the current date and time
$now = new DateTime();

// dates can be output using different formats: http://php.net/manual/en/function.date.php

$xyz=$now->format(' H:i:s');  
echo $xyz;

	
	 $drop=$_POST['drop_location'] ;
	 $pickup=$_POST['pick_up'];

	echo $drop; 
 
  

      $query = "SELECT * FROM 
buses 
WHERE TIME>='$xyz' AND Pickup_Location='$pickup' AND Drop_Location='$drop' ORDER BY TIME ASC";
      //$query .= " ORDER BY hire_date ASC";

      $results = mysqli_query($connection, $query);

      if ($results == FALSE) {
        echo "Database query failed. <br/>";
        echo "SQL command: " . $query;
        exit();
      }
    ?>

<form action="comparetime.php" method="POST">

    <nav>
      <ul>
        <li>
          <a href="index.php">Home</a>
        </li>
        <li>
          <a href="employees.php">Employees</a>
        </li>
      </ul>
    </nav>

    <div class="container">
      <div class = "columns">
        <div class="column col-10 col-mx-auto">

          <a href="addEmployee.php" class="btn"> Add Employee </a>


          <table class="table">
            <tr>
            
              
             <th>ID</th>
              <th>Pickup_Location</th>
              <th>Drop_Location</th>
              <th>Time</th>
			   <th>Day</th>
			  
              <th>&nbsp;</th>
              <th>&nbsp;</th>
            
			  <th>&nbsp;</th>
            </tr>

            <?php while ($employee = mysqli_fetch_assoc($results)) { ?>
              <tr>
              
			     
				  
				 <td><?php echo $employee['ID']; ?></td>
			     <td><?php echo $employee['Pickup_Location']; ?></td>
				   <td><?php echo $employee['Drop_Location']; ?></td>
				     <td><?php echo $employee['Time']; ?></td>
					  <td><?php echo $employee['Day']; ?></td>
					 
               
                <td><a class="action" href="<?php echo 'show.php?id=' . $employee['id']; ?>">View</a></td>
                <td><a class="action" href="<?php echo 'edit.php?id=' . $employee['id']; ?>">Edit</a></td>
                <td><a class="action" href="<?php echo 'delete.php?id='. $employee["id"]; ?>">Delete</a></td>
              </tr>
            <?php } ?>

          </table>


        </div> <!--// col-12 -->
      </div> <!-- // column -->
    </div> <!--// container -->

    <footer>
      &copy; <?php echo date("Y") ?> Cestar College
    </footer>
</form>
    <?php
      // clean up and close database
      mysqli_free_result($results);
      mysqli_close($connection);
    ?>

  </body>
</html>
