<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Theme Made By www.w3schools.com - No Copyright -->
  <title>Bootstrap Theme Company Page</title>
 
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bootstrap.min.css">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  

  <style>
  body {
      font: 400 15px Lato, sans-serif;
      line-height: 1.8;
      /*color: #818181;*/
	  font-family: 'Raleway', sans-serif;
  }

  .navbar {
      margin-bottom: 0;
      background-color: #f4511e;
      /*z-index: 999;*/
      /*border: 0;*/
      font-size: 12px !important;
      /*line-height: 1.42857143 !important;*/
      letter-spacing: 3px;
      border-radius: 0;
      font-family: Montserrat, sans-serif;
  }
  .navbar li a, .navbar .navbar-brand {
       margin-top: 0;
  }
  .navbar-nav li a:hover {
      /*color: #f4511e !important;*/
      background-color:   #fbb6b6 !important;

  }
  .navbar-default .navbar-toggle {
      border-color: transparent;
      /*color: #fff !important;*/
  }
  .navbar-default .navbar-nav>.active>a, .navbar-default .navbar-nav>.active>a:focus, .navbar-default .navbar-nav>.active>a:hover{
    color:#555 important!;
  }
 
  </style>
</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">

<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header" >
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                            
      </button>
      <a class="navbar-brand" href="index.php"> <img src="Lambton_College_Logo.jpg" width="170" height="50"></a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="index.php">HOME</a></li>
        <li><a href="aboutus.php">ABOUT</a></li>
        <li><a href="Showroutes.php">SHOW ROUTES</a></li>
        <li><a href="Contactus.php">CONTACT US</a></li>
        <li><a href="login.php">LOGIN</a></li>
      </ul>
    </div>
  </div>
</nav>


<body>
</body>
</html>



</body>
</html>
