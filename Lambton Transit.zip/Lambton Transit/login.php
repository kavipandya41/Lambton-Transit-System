<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Login & Registration System</title>
<link rel="stylesheet" href="style.css" type="text/css"/>
</head>
<body>
<center>
<div id="login-form">
<form method="POST" action="login.php">
<h1>Lambton Transit</h1>
<table align="center" width="30%" border="0">

<tr>
<td><input type="text" name="id" placeholder="Your ID" required /></td>
</tr>
<tr>
<td><input type="password" name="pass" placeholder="Your Password" required /></td>
</tr>
<tr>
<td><button type="submit" name="btn-login">Sign In</button></td>
</tr>
<tr>
<td><a href="register.php">New? <b><u>Register</u></b> With Us</a></td>
</tr>
</table>
</form>
</div>
</center>
</body>
</html>


<?php
session_start();

$conn=mysqli_connect("localhost","root","","ltransit");
if (!$conn)
 {
    die("Connection failed: " . mysqli_connect_error());
 }
unset($_SESSION['user']);
if(isset($_SESSION['user'])!="")
{
	if($_SESSION['user']==1)
	{		
		header("Location: user.php");
	}
	else if($_SESSION['user']!=1)
	{
		header("Location: admin.php");
	}
}
if(isset($_POST['btn-login']))
{
    $email = ($_POST['id']);
	$pass = ($_POST['pass']);
	$res=mysqli_query($conn,"SELECT * FROM users_info WHERE L_ID='$email' and password='$pass'");
	$row=mysqli_fetch_array($res);
	$count = mysqli_num_rows($res);
	if ($count == 1) 
	{
			if ($row['type'] == "user") 
			{
				$_SESSION['user'] = $row['L_ID'];
				header ( "location: user.php" );				
			} 
			else if ($row ['type'] == "admin")
			{				
				$_SESSION['user'] = $row['L_ID'];
				header ( "location: admin.php" );				
			} 
    }
	else 
	{		
        ?>		
        <script>alert('you have entered the wrong Username or Password');</script>
        <?php
    }
}
?>
}
