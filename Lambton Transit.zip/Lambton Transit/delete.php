<?php
  if (isset($_GET["id"]) == FALSE) {
  }
  $id = $_GET["id"];

  if ($_SERVER['REQUEST_METHOD'] == 'GET') {

    // @TODO: your database code should  here
    //---------------------------------------------------
	$dbhost = "localhost";
      $dbuser = "root";
      $dbpass = "";
      $dbname = "ltransit";

      $connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

      if (mysqli_connect_errno())
      {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
        exit();
      }
	
	$sql 	 = "DELETE FROM buses ";
	$sql 	.= "WHERE ID= '" . $id . "'";
	$sql    .= "LIMIT 1";

	$results = mysqli_query($connection, $sql);
				
	if ($results == FALSE) {
		// there was an error in the sql 
		echo "Database query failed. <br/>";
		echo "SQL command: " . $query;
		exit();
	}
	mysqli_close($connection);
  }

?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <link rel="stylesheet" href="spectre.min.css">
    <link rel="stylesheet" href="spectre-exp.min.css">
    <link rel="stylesheet" href="spectre-icons.min.css">
	
  </head>
  <body>
    <header>
      <h1 style="text-align:center;"> ADMIN PANEL </h1>
    </header>

    <div class="container">
      <div class = "columns">
        <div class="column col-10 col-mx-auto">

			<!-- @TODO: Ask user to confirm they want to get delete a person! -->
			<h3> ARE YOU SURE YOU WANNA DELETE?! </h3>
			<form action = "admin.php" method ="POST">
				<button type="submit"class="btn btn-primary center-block" name="choice"> Yes! </button>
			</form>

        </div> 
      </div> 
    </div> 

    

  </body>
</html>
