<?php
session_start();
if(isset($_SESSION['user'])!="")
{
	header("Location: register.php");
}

$conn = mysqli_connect("localhost","root","","ltransit");

if(isset($_POST['btn-signup']))
{
	$fname = ($_POST['fname']);
	$lname = ($_POST['lname']);
	$lid = ($_POST['L_ID']);
	$phonenum = ($_POST['phonenum']);
	$upass = ($_POST['pass']);
	
	if(mysqli_query($conn,"INSERT INTO users_info(first_name,last_name,password,phone_number,type,L_ID) VALUES('$fname','$lname','$upass','$phonenum','user','$lid')"))
	{
		?>
        <script>alert('successfully registered ');</script>
        <?php
	}
	else
	{
		?>
        <script>alert('error while registering you...');</script>
        <?php
	}
}
?>


<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Login & Registration System</title>
<link rel="stylesheet" href="style.css" type="text/css" />

</head>
<body>
<center>
<div id="login-form">
<form method="post">
<table align="center" width="30%" border="0">
<tr>
<td><input type="text" name="fname" placeholder="First Name" required /></td>
</tr>
<tr>
<td><input type="text" name="lname" placeholder="Last Name" required /></td>
</tr>
<tr>
<td><input type="text" name="L_ID" placeholder="Your Lambton ID" required /></td>
</tr>
<tr>
<td><input type="password" name="pass" placeholder="Your Lambton Password" required /></td>
</tr>
<tr>
<td><input type="text" name="phonenum" placeholder="Phone Number" required /></td>
</tr>
<tr>
<td><input type="hidden" name="type" value="user" /></td>
</tr>
<tr>
<td><button type="submit" name="btn-signup">Lets Get Started</button></td>
</tr>
<tr>
<td><a href="index.php">Login Here</a></td>
</tr>
</table>
</form>
</div>
</center>
</body>
</html>