<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Theme Made By www.w3schools.com - No Copyright -->
  <title>Bootstrap Theme Simply Me</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  

  <style>
  body {
      font-family: 'Raleway', sans-serif;
      line-height: 1.8;
      color: #f5f6f7;
	  
  }
 
  .jumbotron{
    max-height: 100%;
    margin-top: 100px;
    color: black;
  }
  .jumbotron img{
     max-width:1100px;
     margin-left: 70px;
     margin-bottom: 20px;
  }
  .lead {
   color: black;
   text-align: center;
   margin-top: 45px;
  }
  .address p{
    color: black;
    margin-left: 60px;
  }
.anotheraddress{
margin-top: 370px;
}

  </style>
</head>
<body>
<?php
include("Header.php");
?>



<div class="jumbotron jumbotron-fluid">
  <div class="container">

    <div class="col-md-4">
    <img src="contact-us (1).jpg ">
    
    <p class="lead"></p>
    <div style="margin-left: 100px;">
      <i class="fa fa-phone-square fa-3x" style="color:blue;"></i>
    </div>
    <div class="address">
      <p>Transportation</p>
      <p>519-542-7751 Ext. 3315</p>
      <p>Room M106</p>
      <p>Fax: 519-541-2446</p>
      <p>alumni@lambtoncollege.ca</p>
    </div>
   </div>
   <div class="col-md-4">

    
    <p class="anotheraddress"></p>
    <div style="margin-left: 100px;">
      <i class="fa fa-map-marker fa-3x" style="color: blue;" ></i>
    </div>
    <div class="address">
      <p>Campus Address</p>
      <p>265 Yorkland Blvd,  </p>
      <p>North York,</p>
      <p>ON M2J 1S5</p>
      
    </div>
   </div>
</div>
</div>

<?php
include("Footer.php");
?>

</body>
</html>
