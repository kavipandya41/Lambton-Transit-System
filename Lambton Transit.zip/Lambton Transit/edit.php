<?php
if (isset($_GET["id"]) == FALSE) {
  header("Location: " . "admin.php");
  exit();
}

$id = $_GET["id"];

	$dbhost = "localhost";
      $dbuser = "root";
      $dbpass = "";
      $dbname = "ltransit";

      $connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

      if (mysqli_connect_errno())
      {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
        exit();
      }

	
	$sql 	 = "SELECT * FROM buses ";
	$sql 	.= "WHERE ID='" . $id . "'";

	$results = mysqli_query($connection, $sql);
				
	if ($results == FALSE) {
		// there was an error in the sql 
		echo "Database query failed. <br/>";
		echo "SQL command: " . $query;
		exit();
	}
	
	$person = mysqli_fetch_assoc($results);

	print_r($person);
	
	// 5. Close database connection
	mysqli_close($connection);


//---------------------------------------------------




if ($_SERVER['REQUEST_METHOD'] == 'POST') {

  // get items from DATABASE
  $person = [];
  $person["ID"] = $_POST['ID'];
  $person["Pickup_Location"] = $_POST['Pickup_Location'];
  $person["Drop_Location"] = $_POST['Drop_Location'];
   $person["Time"] = $_POST['Time'];
    $person["Day"] = $_POST['Day'];

  // @TODO: your database code should  here
  //---------------------------------------------------

	$dbhost = "localhost";
      $dbuser = "root";
      $dbpass = "";
      $dbname = "ltransit";

      $connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

      if (mysqli_connect_errno())
      {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
        exit();
      }
	
	$sql 	 = "UPDATE buses SET ";
	$sql 	.= "ID=" . $person["ID"] . ", ";
	$sql 	.= "Pickup_Location='" . $person["Pickup_Location"] . "', ";
	$sql 	.= "Drop_Location='" . $person["Drop_Location"] . "', ";
	$sql 	.= "Time='" . $person["Time"] . "', ";
	$sql 	.= "Day='" . $person["Day"] . "' ";
	$sql 	.= "WHERE ID= " . $id . " ";
	$sql    .= "LIMIT 1";
		
	
	

	$results = mysqli_query($connection, $sql);
				
	if ($results == FALSE) {
		// there was an error in the sql 
		echo "Database query failed. <br/>";
		echo "SQL command: " . $sql;
		exit();
	}
	mysqli_close($connection);
}








?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <link rel="stylesheet" href="spectre.min.css">
    <link rel="stylesheet" href="spectre-exp.min.css">
    <link rel="stylesheet" href="spectre-icons.min.css">
  </head>
  <body>
    <header>
      <h1> ADMIN PANEL </h1>
    </header>

    <div class="container">
      <div class = "columns">
        <div class="column col-10 col-mx-auto">

          <!-- @TODO: fill in the ACTION and METHOD portions -->
          <form action="<?php echo "edit.php?id=" . $id; ?>" method="POST" class="form-group">
            <label class="form-label" for="ID">ID</label>
            <input type="text" name="ID" value="<?php echo $person['ID']; ?>" />

            <label class="form-label" for="Pickup_Location">Pickup_Location</label>
            <input type="text" name="Pickup_Location" value="<?php echo $person['Pickup_Location']; ?>" />

            <label class="form-label" for="Drop_Location">Drop_Location</label>
            <input type="text" name="Drop_Location" value="<?php echo $person['Drop_Location']; ?>" />
			
			
			<label class="form-label" for="Time">Time</label>
            <input type="text" name="Time" value="<?php echo $person['Time']; ?>" />
			
			
			<label class="form-label" for="Day">Day</label>
            <input type="text" name="Day" value="<?php echo $person['Day']; ?>" />
			</br>
            <p>
              <input type="submit" value="Update Bus" />
            </p>
          </form>

          <p>
            <a href="admin.php" class="btn">Go Back</a>
          </p>

        </div> <!--// col-12 -->
      </div> <!-- // column -->
    </div> <!--// container -->

    <footer>
      &copy; <?php echo date("Y") ?> Cestar College
    </footer>

  </body>
</html>
