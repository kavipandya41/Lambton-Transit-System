<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Theme Made By www.w3schools.com - No Copyright -->
  <title>Bootstrap Theme Simply Me</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/3/w3.css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
  body {
      font-family: 'Raleway', sans-serif;
      line-height: 2;
      color: #f5f6f7;
	   
	 
	  
  }
footer{
  padding: 20px;
  background-color: black;
  text-align:  center;
}

  </style>
}
</head>
<body>


<!-- Footer -->
<footer class="w3-container w3-padding-16 w3-center w3-blue w3-large" style="letter-spacing: 20px;">
        <a title="Facebook" href="https://www.facebook.com/lambtoncollege?v=wall">
             <i class="fa fa-facebook-official" style="font-size:36px"></i></a>
        <a title="Twitter" href="https://twitter.com/lambtoncollege">
             <i class="fa fa-twitter-square" style="font-size:36px"></i> </a>
        <a title="YouTube" href="https://www.youtube.com/user/LambtonCollegeSarnia">
             <i class="fa fa-youtube" style="font-size:36px"></i></a>
       
        <a title="Instagram" href="https://instagram.com/lambtoncollege/">
             <i class="fa fa-instagram" style="font-size:36px"></i></a>
      
       <h5 style="letter-spacing: 5px;"">Copyright  &copy; CARK </h5>
      </footer>

</body>
</html>
