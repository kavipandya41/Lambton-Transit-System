
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
	
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<style>
	h1
	{
	padding-bottom: 20px;
	color: rgba(12,45,78,11);
	font-size: 38px;
	text-align:center;
       text-shadow: 0 1px 0 #ffffff, 0 2px 0 #ffffff,
             0 3px 0 #999999, 0 4px 0 #888888,
             0 5px 0 #888888, 0 6px 0 #777777,
             0 7px 0 #777777, 0 8px 7px rgba(0, 0, 0, 0.1),
             0 9px 10px rgba(0, 0, 0, 0.1);
	}
h6{
  text-align: center; 
  font-size: xx-large; 
  font-family: sans-serif; 
}
	</style>
  </head>
  <body>
  <?php
	include("Header.php");
  ?>
  <nav class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                            
      </button>
      <a class="navbar-brand" href="testing for transportation.php"> <img src="Lambton_College_Logo.jpg" width="170" height="50" /a>Transportation
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="testing for transportation.php">HOME</a></li>
        <li><a href="aboutus.php">ABOUT</a></li>
        <li><a href="Showroutes.php">SHOW ROUTES</a></li>
        <li><a href="Contactus.php">CONTACT US</a></li>
        <li><a href="index.php">LOG OUT</a></li>
      </ul>
    </div>
  </div>
</nav>
    <header style="margin-top:75px;">
      <h1 style=""> Lambton Transit </h1>
    </header>
	
	
<form method="POST" action="admin.php">
    <div class="container">
      <div class = "columns">
        <div class="column col-10 col-mx-auto">
			<h6>Select Pickup Location</h6>
			<select name="page1" id="page1" required value="Lambton College" class="form-control" >
				<option selected="selected">Select One</option>
				<option value="Lambton College">Lambton College</option>
				<option value="Brampton">Brampton</option>
				<option value="Mississuaga">Mississuaga</option>
			</select>
			<h6>Select Drop Location</h6>
			<select name="page2" id="page2" required value="Brampton" class="form-control">
				<option selected="selected">Select One</option>
				<option value="Lambton College">Lambton College</option>
				<option value="Brampton">Brampton</option>
				<option value="Mississuaga">Mississuaga</option>
				<option value="Mississuaga/Brampton">Mississuaga/Brampton</option>
			</select>
			</br>
			<button type="submit" name="search" class="btn btn-primary center-block" style="margin : 0 auto;">Next Buses!</button> 
			</br>
			<a href="addBus.php" class="btn btn-primary center-block"> Add Bus..</a>
			</br>
			</br>

</form>
    <?php

      $dbhost = "localhost";
      $dbuser = "root";
      $dbpass = "";
      $dbname = "ltransit";

      $connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

      if (mysqli_connect_errno())
      {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
        exit();
      }

date_default_timezone_set("America/New_York");
$now = new DateTime();

$xyz=$now->format('H:i:s');  
if(isset($_POST['search']))
{
	
    $pickup = ($_POST['page1']);
	$drop = ($_POST['page2']);	
      $query = "SELECT * FROM buses WHERE TIME>='$xyz' AND Pickup_Location='$pickup' AND Drop_Location='$drop' ORDER BY TIME ASC";

      $results = mysqli_query($connection, $query);
		$count = mysqli_num_rows($results);
      if ($results == FALSE)
	 {
        echo "Database query failed. <br/>";
        echo "SQL command: " . $query;
        exit(); 
	 }
	 if($count != 0)
	 {
    ?>
          <table class="table table-striped">
            <tr>   
             <th>ID</th>
              <th>Pickup_Location</th>
              <th>Drop_Location</th>
              <th>Time</th>
			   <th>Day</th>		  
            </tr>
            <?php while ($employee = mysqli_fetch_assoc($results)) { ?>
              <tr> 
				 <td><?php echo $employee['ID']; ?></td>
			     <td><?php echo $employee['Pickup_Location']; ?></td>
				 <td><?php echo $employee['Drop_Location']; ?></td>
			     <td><?php echo $employee['Time']; ?></td>
				 <td><?php echo $employee['Day']; ?></td>
				<td><a class="action" href="<?php echo 'show.php?id=' . $employee['ID']; ?>">View</a></td>
                <td><a class="action" href="<?php echo 'edit.php?id=' . $employee['ID']; ?>">Edit</a></td>
                <td><a class="action" href="<?php echo 'delete.php?id='. $employee['ID']; ?>">Delete</a></td>
              </tr>
            <?php } ?>
          </table>
		 <a href="test.php" class="btn btn-primary center-block"> Send Message..</a>
		  </div> 
      </div> 
    </div> 
	
    <?php
	if(isset($_POST['msg']))
	{
		include("test.php");
	}
      mysqli_free_result($results);
      mysqli_close($connection);
	 }
	 else
	 {		
			echo "</br>";
			echo "<h1> Sorry No Buses available for this route at this time.....";
	 }
}
    ?>
  </body>
</html>
