<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Theme Made By www.w3schools.com - No Copyright -->
  <title>Bootstrap Theme Simply Me</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/3/w3.css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
  body {
      font-family: 'Raleway', sans-serif;
      line-height: 1.8;
      color: #f5f6f7;
	  
  }
  p {font-size: 16px;}
  .margin {margin-bottom: 45px;}
  .bg-1 { 
      background-color:#  4682B4; /* Green */
      color: #ffffff;

  }
  .bg-2 { 
      background-color: 	#6495ED; /* Dark Blue */
      color: #ffffff;
  }
  .bg-3 { 
      background-color: #ffffff; /* White */
      color: #555555;
  }
  .bg-4 { 
      background-color: #2f2f2f; /* Black Gray */
      color: #fff;
  }
  .container-fluid {
      padding-top: 70px;
      padding-bottom: 70px;
  }
  .navbar {
      padding-top: 15px;
      padding-bottom: 15px;
      border: 0;
      border-radius: 0;
      margin-bottom: 0;
      font-size: 12px;
      letter-spacing: 5px;
  }
  .navbar-nav  li a:hover {
      color: #1abc9c !important;
  }
  

  </style>
</head>
<body>
<?php

include("Header.php");
?>
<section>
       <img class="mySlides" src="2016-09-23-RenewInfrastructure.jpg" style="width:100%">
       <img class="mySlides" src="1297872782556_ORIGINAL.jpg" style="width:100%">
       <img class="mySlides" src="banner-alumni.jpg" style="width:100%">
        <img class="mySlides" src="1297872782556_ORIGINAL.jpg" style="width:100%"> </section>
<script>
var myIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}    
    x[myIndex-1].style.display = "block";  
    setTimeout(carousel, 2000); 
}
</script>

<section class="w3-container  w3-content w3-justify w3-blue  " style="max-width:100%;border-color:pink;">
	   <p >
	      The Alumni Association at Lambton College is made up of dedicated volunteer alumni who sit on the board and all share a common goal of serving the needs of the alumni community. This is accomplished by supporting alumni activities and by working with the Foundation and the Student Administrative Council to foster a lifelong relationship between Lambton College and its alumni.

		<p>By staying in touch with its alumni Lambton College and its current students can benefit greatly from the partnerships and connections that can be made through past students who are now playing an active role in their specific fields.</p>

		<p>Alumni are encouraged to stay in touch with Lambton College. By staying in touch you are ensuring that the programs you graduated from are continuing to live up to the industry standard.</p>

		<p>Participation can take many forms including:</p>

		<ul>
			<li>Attending social events</li>
			<li>Meeting up with other alumni</li>
			<li>Taking advantage of alumni benefits</li>
			<li>Playing a role on the board</li>
			<li>Planning a class reunion</li>

		</ul>
		</section>

	<section class="w3-row-padding w3-center w3-black">
	  <article class="w3-third">
	    <p>Together</p>
	    <img src="2016-09-23-RenewInfrastructure.jpg" alt="Random Name" style="width:100%; height:200px; ">
	  </article>
	  <article class="w3-third">
	    <p>Campus</p>
	    <img src="1297872782556_ORIGINAL.jpg" alt="Random Name" style="width:100%;height:200px;">
	  </article>
	  <article class="w3-third">
	    <p>Alumini Association</p>
	    <img src="banner-alumni.jpg" alt="Random Name" style="width:100%;height:200px;">
	  </article>
	</section>
</body>
<?php
include("Footer.php");
?>

</body>
</html>
