<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <link rel="stylesheet" href="../css/spectre.min.css">
    <link rel="stylesheet" href="../css/spectre-exp.min.css">
    <link rel="stylesheet" href="./css/spectre-icons.min.css">
  </head>
  <body>
    <header>
      <h1> ADMIN AREA </h1>
    </header>

    <?php

      $dbhost = "localhost";
      $dbuser = "root";
      $dbpass = "";
      $dbname = "lambtontransit";

      $connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

      if (mysqli_connect_errno())
      {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
        exit();
      }

      $query = "SELECT * FROM buses";
      //$query .= " ORDER BY hire_date ASC";

      $results = mysqli_query($connection, $query);

      if ($results == FALSE) {
        echo "Database query failed. <br/>";
        echo "SQL command: " . $query;
        exit();
      }
    ?>

    <div class="container">
      <div class = "columns">
        <div class="column col-10 col-mx-auto">

          <a href="addEmployee.php" class="btn"> Add Bus </a>


          <table class="table">
            <tr>
              <th>ID</th>
              <th>Pickup_Location</th>
              <th>Drop_Location</th>
              <th>Time</th>
			   <th>Day</th>
              <th>&nbsp;</th>
              <th>&nbsp;</th>
            
			  <th>&nbsp;</th>
            </tr>

            <?php while ($employee = mysqli_fetch_assoc($results)) { ?>
              <tr>
               <td><?php echo $employee['ID']; ?></td>
			     <td><?php echo $employee['Pickup_Location']; ?></td>
				   <td><?php echo $employee['Drop_Location']; ?></td>
				     <td><?php echo $employee['Time']; ?></td>
					  <td><?php echo $employee['Day']; ?></td>
              
                <td><a class="action" href="<?php echo 'show.php?id=' . $employee['ID']; ?>">View</a></td>
                <td><a class="action" href="<?php echo 'edit.php?id=' . $employee['ID']; ?>">Edit</a></td>
                <td><a class="action" href="<?php echo 'delete.php?id='. $employee['ID']; ?>">Delete</a></td>
              </tr>
            <?php } ?>

          </table>


        </div> <!--// col-12 -->
      </div> <!-- // column -->
    </div> <!--// container -->

    <footer>
      &copy; <?php echo date("Y") ?> Cestar College
    </footer>

    <?php
	 
      // clean up and close database
      mysqli_free_result($results);
      mysqli_close($connection);
    ?>

  </body>
</html>