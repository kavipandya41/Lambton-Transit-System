-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 14, 2018 at 12:03 AM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lambtontransit`
--

-- --------------------------------------------------------

--
-- Table structure for table `buses`
--

CREATE TABLE `buses` (
  `ID` int(10) NOT NULL,
  `Pickup_Location` varchar(250) NOT NULL,
  `Drop_Location` varchar(250) NOT NULL,
  `Time` time NOT NULL,
  `Day` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `buses`
--

INSERT INTO `buses` (`ID`, `Pickup_Location`, `Drop_Location`, `Time`, `Day`) VALUES
(1, 'Brampton', 'Lambton College', '06:45:00', 'Weekdays'),
(2, 'Mississuaga', 'Lambton College', '06:45:00', 'Weekdays'),
(3, 'Brampton', 'Lambton College', '10:20:00', 'Weekdays'),
(4, 'Brampton', 'Lambton College', '11:00:00', 'ALL'),
(5, 'Mississuaga', 'Lambton College', '11:15:00', 'Weekdays'),
(6, 'Brampton', 'Lambton College', '11:40:00', 'ALL'),
(7, 'Brampton', 'Lambton College', '12:30:00', 'ALL'),
(8, 'Mississuaga', 'Lambton College', '11:00:00', 'ALL'),
(9, 'Brampton', 'Lambton College', '14:30:00', 'Weekdays'),
(10, 'Brampton', 'Lambton College', '15:40:00', 'Weekdays'),
(11, 'Brampton', 'Lambton College', '16:00:00', 'ALL'),
(12, 'Brampton', 'Lambton College', '16:25:00', 'Weekdays'),
(13, 'Mississuaga', 'Lambton College', '16:25:00', 'Weekdays'),
(14, 'Lambton College', 'Brampton', '23:30:00', 'ALL'),
(15, 'Lambton College', 'Mississuga/Brampton', '23:00:00', 'ALL'),
(16, 'Lambton College', 'Brampton', '13:30:00', 'ALL'),
(17, 'Lambton College', 'Mississuaga/Brampton', '13:45:00', 'ALL'),
(18, 'Lambton College', 'Mississuaga/Brampton', '14:30:00', 'Weekdays'),
(19, 'Lambton College', 'Mississuaga/Brampton', '15:30:00', 'ALL'),
(20, 'Lambton College', 'Mississuaga/Brampton', '17:00:00', 'ALL'),
(21, 'Lambton College', 'Brampton', '17:05:00', 'Weekdays'),
(22, 'Lambton College', 'Mississuaga/Brampton', '18:00:00', 'ALL'),
(23, 'Lambton College', 'Mississuaga/Brampton', '19:30:00', 'ALL'),
(24, 'Lambton College', 'Mississuaga/Brampton', '19:45:00', 'ALL'),
(25, 'Lambton College', 'Mississuaga/Brampton', '20:10:00', 'ALL'),
(26, 'Lambton College', 'Brampton', '21:35:00', 'Weekdays'),
(27, 'Lambton College', 'Mississuaga/Brampton', '21:45:00', 'Weekdays'),
(28, 'Lambton College', 'Mississuaga/Brampton', '22:20:00', 'ALL');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `buses`
--
ALTER TABLE `buses`
  ADD PRIMARY KEY (`ID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
