
<?php

// 0. Tell PHP you are going to return a JSON
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

// 1. Create a database connection
$connection = mysqli_connect("localhost", "root", "", "ltransit");

// show an error message if PHP cannot connect to the database
if (!$connection)
{
  $output = array("error" => "Failed to connect to MySQL: " . mysqli_connect_error());
  echo json_encode($output);
  exit();
}

// 2. Perform database query
$sql = "SELECT * FROM buses";

$results = mysqli_query($connection, $sql);
if ($results == FALSE) {
  $output = array("error" => "Database quer failed. SQL command: " . $sql);
  echo json_encode($output);
  exit();
}

$schedule = [];

while ($row = mysqli_fetch_assoc($results)) {
  $table = array(
    "id" => $row["ID"],
    "pickup" => $row["Pickup_Location"],
    "drop" => $row["Drop_Location"],
	"time" => $row["Time"],
	"day" => $row["Day"]);
  array_push($schedule, $table);
}

echo json_encode($schedule);
?>
