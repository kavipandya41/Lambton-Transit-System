<?php
session_start();
/*if(isset($_SESSION['user'])!="")
{
	header("Location: addBus.php");
}*/

$conn = mysqli_connect("localhost","root","","ltransit");

if(isset($_POST['addBus']))
{
	$id = ($_POST['ID']);
	$pickup = ($_POST['pickup']);
	$drop = ($_POST['drop']);
	$time = ($_POST['time']);
	$day = ($_POST['day']);	
	if(mysqli_query($conn,"INSERT INTO buses(ID,Pickup_Location,Drop_Location,Time,Day) VALUES('$id','$pickup','$drop','$time','$day');"))
	{
		?>
        <script>alert('Successfully BUS ADDED...');</script>
        <?php
	}
	else
	{
		?>
        <script>alert('Error while Adding BUS...');</script>
        <?php
	}
}
?>


<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Bus Schedule...</title>
<link rel="stylesheet" href="style.css" type="text/css" />

</head>
<body>
<center>
<div id="login-form">
<form method="post" action="addBus.php">
<table align="center" width="30%" border="0">
<tr>
<td><input type="text" name="ID" placeholder="Enter BUS ID" required /></td>
</tr>
<tr>
<td><input type="text" name="pickup" placeholder="Enter Pickup Location" required /></td>
</tr>
<tr>
<td><input type="text" name="drop" placeholder="Enter Drop Location" required /></td>
</tr>
<tr>
<td><input type="text" name="time" placeholder="Enter Time" required /></td>
</tr>
<tr>
<td><input type="text" name="day" placeholder="Enter Days of Running" required /></td>
</tr>
<tr>
<td><button type="submit" name="addBus">ADD BUS</button></td>
</tr>
<tr>
<td><a href="admin.php">Back To Schedule....</a></td>
</tr>
</table>
</form>
</div>
</center>
</body>
</html>