<?php
require __DIR__ . '/twilio-php-master/Twilio/autoload.php';

use Twilio\Rest\Client;

echo "Sending SMS! <br>";
// Your Account SID and Auth Token from twilio.com/console
$account_sid = 'AC46a592f8679eaa205abe888d8bc5a9a7';
$auth_token = 'b883c6c7f475f2c06c05d1a86ec04bde';

// A Twilio number you own with SMS capabilities
$twilio_number = "+12895122341";

$client = new Client($account_sid, $auth_token);

print_r($client);

$client->messages->create
(
    '+16479162327',
    array(
        'from' => $twilio_number,
        'body' => 'Your Bus is Delayed For Some Time..!'
    )
);

echo "Done sending SMS! <br>";
?>