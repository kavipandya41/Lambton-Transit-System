<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Theme Made By www.w3schools.com - No Copyright -->
  <title>Bootstrap Theme Simply Me</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
  body {
      font-family: 'Raleway', sans-serif;
      
      color: #f5f6f7;
	  
  }
 .abtimg{
     margin-left: 300px;
    margin-top: 100px;
    padding-bottom: 30px;
 }
  .info{
    max-width: 70%;
    text-align: center;s
  }
  p{
    color: black;
    text-align: justify;
  }
  .abtusdiv{

    max-width: 1150px;
    text-align: justify;
  }
  ol{
    color: black;
  }
  .abtusdiv p,ol{
    text-align: justify;
    margin-left: 300px;
  }

  </style>
</head>
<body>
<?php

include("Header.php");
?>
	<div class="abtusdiv">
     <img  class="abtimg"src="banner-alumni.jpg" >
     <h3 style="text-align:center;margin-left:350px;color:black;">Our College</h3>
     <p>Lambton College recently celebrated 50 years as a leader in post-secondary education.
      For the past five decades, we've worked in partnership with the Sarnia-Lambton community to create a region of innovators, strengthening our local economy, and working together to meet industry demand for skilled employees.</p>

<p>This continued support from our greater community has allowed Lambton College to grow to become the #1 Applied Research College in Ontario and third in Canada.</p>

<p>Our commitment to experiential learning and our ability to adapt to modern teaching methods with initiatives like Mobile Learning and our exclusive Class+ Experience, means our graduates are some of the best in the country. Lambton College alumni are leaders in the industry - nurses, firefighters, police officers, power engineers, and community service workers.</p>

<p>Much of this can be attributed to our career-focused programs, exceptional faculty and world-class facilities such as our Fire & Public Safety Centre of Excellence. Future opportunities for our students and our community are being further enhanced through projects such as our new NOVA Chemicals Health & Research Centre and Athletics & Fitness Complex, as well as the renovation and upgrade of our Centre of Excellence in Energy & Bio-Industrial Technologies.</p>

<p>According to the latest Key Performance Indicator (KPI) report, Lambton College has the highest employer satisfaction rate in the province. Not only did Lambton College take the top spot in the rankings, but our College earned a perfect score, with 100 per cent of employers surveyed reporting that they were satisfied or very satisfied with the skills of their new hires.</p>

<p>This report reinforces what we've worked hard to achieve: a supportive and innovative environment that bridges the gap between education and industry.</p>

<p>Throughout our 50th Anniversary festivities, we celebrated the pioneers who laid the foundation of our success, such as former Premier William G. Davis, who envisioned the Ontario College System and could be considered the ultimate icon of innovation in education.</p>

<p>As a College, we continue to foster those foundational values every single day. We welcome you to join us on this journey, as we uphold our position as a post-secondary leader in education, training and research, while inspiring the next generation of community and industry leaders.</p>

<p>Judith Morris,</p>
<p>President & CEO</p>
<p>Lambton College</p>
</div>


<?php
include("Footer.php");
?>

</body>
</html>
