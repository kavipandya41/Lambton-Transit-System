<!DOCTYPE html>
<html>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/3/w3.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<body>
	<nav class=" w3-pink w3-bar w3-padding-4  w3-section" >
		Lambton College Transportation
	  <a href="webpage.php" class="w3-button w3-bar-item w3-right">Login</a>
	  <a href="Ticketpricing.php" class="w3-button w3-bar-item w3-right">Ticket Pricing</a>
	  <a href="Showroutes.php" class="w3-button w3-bar-item w3-right">Show Routes</a>
	  <a href="aboutus.php" class="w3-button w3-bar-item w3-right">About Us</a>
	   <a href="webpage.php" class="w3-button w3-bar-item w3-right">Home</a>
	</nav>
    
     
	<section>
       <img class="mySlides" src="2016-09-23-RenewInfrastructure.jpg" style="width:100%">
       <img class="mySlides" src="1297872782556_ORIGINAL.jpg" style="width:100%">
       <img class="mySlides" src="banner-alumni.jpg" style="width:100%">
        <img class="mySlides" src="1297872782556_ORIGINAL.jpg" style="width:100%">
    </section>

    <section class="w3-container  w3-content w3-justify w3-blue  " style="max-width:100%;border-color:pink;">
	   <p >
	      The Alumni Association at Lambton College is made up of dedicated volunteer alumni who sit on the board and all share a common goal of serving the needs of the alumni community. This is accomplished by supporting alumni activities and by working with the Foundation and the Student Administrative Council to foster a lifelong relationship between Lambton College and its alumni.

		<p>By staying in touch with its alumni Lambton College and its current students can benefit greatly from the partnerships and connections that can be made through past students who are now playing an active role in their specific fields.</p>

		<p>Alumni are encouraged to stay in touch with Lambton College. By staying in touch you are ensuring that the programs you graduated from are continuing to live up to the industry standard.</p>

		<p>Participation can take many forms including:</p>

		<ul>
			<li>Attending social events</li>
			<li>Meeting up with other alumni</li>
			<li>Taking advantage of alumni benefits</li>
			<li>Playing a role on the board</li>
			<li>Planning a class reunion</li>

		</ul>
		</section>

	<section class="w3-row-padding w3-center w3-black">
	  <article class="w3-third">
	    <p>Together</p>
	    <img src="2016-09-23-RenewInfrastructure.jpg" alt="Random Name" style="width:100%; height:200px; ">
	  </article>
	  <article class="w3-third">
	    <p>Campus</p>
	    <img src="1297872782556_ORIGINAL.jpg" alt="Random Name" style="width:100%;height:200px;">
	  </article>
	  <article class="w3-third">
	    <p>Alumini Association</p>
	    <img src="banner-alumni.jpg" alt="Random Name" style="width:100%;height:200px;">
	  </article>
	</section>













<script>
// Automatic Slideshow - change image every 3 seconds
var myIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}
    x[myIndex-1].style.display = "block";
    setTimeout(carousel, 3000);
}
</script>



	<!-- Footer -->	


<footer class="w3-container w3-padding-16 w3-center w3-pink w3-large" style="letter-spacing: 20px;">
        <a title="Facebook" href="https://www.facebook.com/lambtoncollege?v=wall">
             <i class="fa fa-facebook-official" style="font-size:36px"></i></a>
        <a title="Twitter" href="https://twitter.com/lambtoncollege">
             <i class="fa fa-twitter-square" style="font-size:36px"></i> </a>
        <a title="YouTube" href="https://www.youtube.com/user/LambtonCollegeSarnia">
             <i class="fa fa-youtube" style="font-size:36px"></i></a>
       
        <a title="Instagram" href="https://instagram.com/lambtoncollege/">
             <i class="fa fa-instagram" style="font-size:36px"></i></a>
      
       <h5 style="letter-spacing: 5px;"">Copyright  &copy; CARK </h5>
	   
	   <img width="25" height="25" alt="rss feed" src="/images/footer/icon-rss-2x.png" >
      </footer>


</body>
</html>