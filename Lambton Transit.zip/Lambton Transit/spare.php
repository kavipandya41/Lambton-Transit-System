if( $count != 0 )
{
      echo"<h1>";
      echo " <br> welcome:".$name ;
	  header('Location: comparetime.php');

      echo"</h1>";
}